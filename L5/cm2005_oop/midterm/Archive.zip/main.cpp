#include "MerkleMain.hpp"

int main()
{
	MerkleMain app{};
	app.init();
}
